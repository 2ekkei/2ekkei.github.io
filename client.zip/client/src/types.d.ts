declare module "*.ogg" {
    const value: string;
    export default value;
}

declare module "*.png" {
    const value: string;
    export default value;
}
